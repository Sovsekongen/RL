#include "slotmachine.h"


